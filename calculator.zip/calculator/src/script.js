// script.js

function calculate() {

    // Get input values

    const currentAge = parseInt(document.getElementById("currentAge").value);

    const retireAge = parseInt(document.getElementById("retireAge").value);

    const currentSavings = parseInt(document.getElementById("currentSavings").value);

    const monthlyContribution = parseInt(document.getElementById("monthlyContribution").value);

    const desiredIncome = parseInt(document.getElementById("desiredIncome").value);

    const inflationRate = parseInt(document.getElementById("inflationRate").value) / 100;

    // Validate inputs

    if (!currentAge || !retireAge || !currentSavings || !monthlyContribution || !desiredIncome) {

        alert("Please fill in all fields!");

        return;

    }

    // Calculate years until retirement

    const yearsToRetire = retireAge - currentAge;

    // Adjust desired income for inflation

    const futureMonthlyIncome = desiredIncome * Math.pow(1 + inflationRate, yearsToRetire);

    const annualIncomeNeeded = futureMonthlyIncome * 12;

    

    // Assume 20 years of retirement (can adjust)

    const totalNeeded = annualIncomeNeeded * 20;

    // Project current savings (assuming 10% annual return)

    const investmentGrowthRate = 0.10;

    const futureValueOfSavings = currentSavings * Math.pow(1 + investmentGrowthRate, yearsToRetire);

    

    // Future value of monthly contributions (annuity calculation)

    const futureValueOfContributions = monthlyContribution * 12 * 

        (Math.pow(1 + investmentGrowthRate, yearsToRetire) - 1) / investmentGrowthRate;

    const totalSavings = futureValueOfSavings + futureValueOfContributions;

    const shortfall = totalNeeded - totalSavings;

    // Display results

    const resultDiv = document.getElementById("result");

    resultDiv.style.display = "block";

    

    resultDiv.innerHTML = `

        <h2>Your Retirement Plan</h2>

        <p>At age ${retireAge}, you'll need: <span class="highlight">R${totalNeeded.toLocaleString()}</span></p>

        <p>Your projected savings: <span class="highlight">R${totalSavings.toLocaleString()}</span></p>

        <p>Shortfall/Surplus: <span class="${shortfall > 0 ? 'red' : 'green'}">R${Math.abs(shortfall).toLocaleString()} ${shortfall > 0 ? 'SHORTFALL' : 'SURPLUS'}</span></p>

        

        <h3>Action Plan</h3>

        <ul>

            <li>Increase monthly contributions by <span class="highlight">R${Math.max(1000, Math.ceil(shortfall / (12 * yearsToRetire))).toLocaleString()}</span></li>

            <li>Consider a <span class="highlight">Tax-Free Savings Account (TFSA)</span> for tax efficiency</li>

            <li>Review Regulation 28 compliance on retirement funds</li>

        </ul>

        

        <p><em>Book a consultation with Winpro to optimize your plan!</em></p>

    `;

}